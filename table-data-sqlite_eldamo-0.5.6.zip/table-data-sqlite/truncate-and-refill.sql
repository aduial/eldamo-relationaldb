delete from cat;
.read sql/cat.sql
delete from doc;
.read sql/doc.sql
delete from entry;
.read sql/entry.sql
delete from entry_doc;
.read sql/entry_doc.sql
delete from example;
.read sql/example.sql
.read sql/files.txt
delete from form;
.read sql/form.sql
delete from gloss;
.read sql/gloss.sql
delete from grammar;
.read sql/grammar.sql
delete from lang;
.read sql/lang.sql
delete from lang_doc;
.read sql/lang_doc.sql
delete from linked;
.read sql/linked.sql
delete from linked_form;
.read sql/linked_form.sql
delete from linked_grammar;
.read sql/linked_grammar.sql
delete from ref;
.read sql/ref.sql
delete from rule;
.read sql/rule.sql
delete from rulesequence;
.read sql/rulesequence.sql
delete from source;
.read sql/source.sql
delete from source_doc;
.read sql/source_doc.sql
delete from type;
.read sql/type.sql
